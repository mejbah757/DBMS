-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2021 at 05:42 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cse311`
--

-- --------------------------------------------------------

--
-- Table structure for table `depts`
--

CREATE TABLE `depts` (
  `Department_id` float NOT NULL,
  `Department_Name` varchar(30) NOT NULL,
  `Manager_id` float DEFAULT NULL,
  `Location_id` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `depts`
--

INSERT INTO `depts` (`Department_id`, `Department_Name`, `Manager_id`, `Location_id`) VALUES
(10, 'Administration', 200, 1700),
(20, 'Marketing', 201, 1800),
(50, 'Shipping', 124, 1500),
(60, 'IT', 103, 1400),
(80, 'Sales', 149, 2500),
(90, 'Executive', 100, 1700),
(110, 'Accounting', 205, 1700),
(190, 'Contracting', NULL, 1700);

-- --------------------------------------------------------

--
-- Table structure for table `emps`
--

CREATE TABLE `emps` (
  `Employee_Id` int(6) NOT NULL,
  `First_Name` varchar(20) DEFAULT NULL,
  `Last_Name` varchar(25) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Phone_Number` int(15) DEFAULT NULL,
  `Hire_Date` date NOT NULL,
  `Job_Id` int(10) NOT NULL,
  `Salary` float(8,2) DEFAULT NULL,
  `Commission_pct` float(2,2) DEFAULT NULL,
  `Manager_id` int(6) DEFAULT NULL,
  `Department_Id` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emps`
--

INSERT INTO `emps` (`Employee_Id`, `First_Name`, `Last_Name`, `Email`, `Phone_Number`, `Hire_Date`, `Job_Id`, `Salary`, `Commission_pct`, `Manager_id`, `Department_Id`) VALUES
(100, 'Steven', 'King', 'SKING', 515123, '0000-00-00', 0, 24000.00, NULL, NULL, 90),
(101, 'Neena', 'Kochar', 'NKOCHAR', 515123, '0000-00-00', 0, 17000.00, NULL, 100, 90),
(102, 'Lex', 'De Haan', 'DEHAAN', 515123, '0000-00-00', 0, 17000.00, NULL, 100, 90),
(103, 'Alexander', 'Hunold', 'AHUNOLD', 590423, '0000-00-00', 0, 9000.00, NULL, 102, 60),
(104, 'Bruce', 'Ernst', 'BERNST', 590423, '0000-00-00', 0, 6000.00, NULL, 103, 60),
(107, 'Diana', 'Lorentz', 'DLORENTZ', 590423, '0000-00-00', 0, 4200.00, NULL, 103, 60),
(124, 'Kevin', 'Mourgos', 'KMORGOS', 650123, '0000-00-00', 0, 5800.00, NULL, 100, 50),
(141, 'Treena', 'Rajs', 'RRAJS', 650121, '0000-00-00', 0, 3500.00, NULL, 124, 50),
(142, 'Curtis', 'Davies', 'CDAVIES', 121123, '0000-00-00', 0, 3100.00, NULL, 124, 50),
(143, 'Randall', 'Matos', 'RMATOS', 121123, '0000-00-00', 0, 2600.00, NULL, 124, 50),
(144, 'Peter', 'Vargas', 'PVARGAS', 121123, '0000-00-00', 0, 2500.00, NULL, 124, 50),
(149, 'Eleni', 'Zlotkey', 'EZLOTKEY', 441344, '0000-00-00', 0, 10500.00, 0.20, 100, 80),
(174, 'Ellen', 'Abel', 'EABEL', 441644, '0000-00-00', 0, 11000.00, 0.30, 149, 80),
(176, 'Jnathon', 'Taylor', 'JTAILOR', 441644, '0000-00-00', 0, 8600.00, 0.20, 149, 80),
(178, 'Kimberely', 'Grant', 'KGRANT', 441644, '0000-00-00', 0, 7000.00, 0.15, 149, NULL),
(200, 'Jennifer', 'Whalem', 'JWHALEN', 515123, '0000-00-00', 0, 4400.00, NULL, 101, 10),
(201, 'Michael', 'Hartstein', 'MHARSTEIN', 515123, '0000-00-00', 0, 13000.00, NULL, 100, 20),
(202, 'Pat', 'Fay', 'PFAY', 603123, '0000-00-00', 0, 6000.00, NULL, 201, 20),
(205, 'Shelley', 'Higgins', 'SHIGGINS', 515123, '0000-00-00', 0, 12000.00, NULL, 101, 110),
(206, 'William', 'Gietz', 'WGIETZ', 515123, '0000-00-00', 0, 8300.00, NULL, 205, 110);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `depts`
--
ALTER TABLE `depts`
  ADD PRIMARY KEY (`Department_id`);

--
-- Indexes for table `emps`
--
ALTER TABLE `emps`
  ADD PRIMARY KEY (`Employee_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
